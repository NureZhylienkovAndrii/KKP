import os
import time
import shutil

from PySide6.QtCore import (
    QThread,
    Signal
)

from app.processing.image_processor import ImageProcessor


class FolderMonitor(QThread):

    image_processed = Signal(dict, float)

    status_changed = Signal(str)

    def __init__(self):

        super().__init__()

        self.running = False

        self.incoming_folder = "images/incoming"

        self.processed_folder = "images/processed"

        self.defects_folder = "images/defects"

        os.makedirs(
            self.incoming_folder,
            exist_ok=True
        )

        os.makedirs(
            self.processed_folder,
            exist_ok=True
        )

        os.makedirs(
            self.defects_folder,
            exist_ok=True
        )

    def run(self):

        self.running = True

        self.status_changed.emit(
            "AUTO MONITORING STARTED"
        )

        processed_files = set()

        while self.running:

            files = [

                f for f in os.listdir(
                    self.incoming_folder
                )

                if f.lower().endswith(
                    (
                        ".png",
                        ".jpg",
                        ".jpeg",
                        ".bmp"
                    )
                )
            ]

            for file_name in files:

                if file_name in processed_files:
                    continue

                file_path = os.path.join(
                    self.incoming_folder,
                    file_name
                )

                try:

                    start_time = time.time()

                    result = (
                        ImageProcessor.process_image(
                            file_path
                        )
                    )

                    end_time = time.time()

                    processing_time = round(
                        end_time - start_time,
                        3
                    )

                    defect_count = result[
                        "defect_count"
                    ]

                    if defect_count > 0:

                        destination = os.path.join(
                            self.defects_folder,
                            file_name
                        )

                    else:

                        destination = os.path.join(
                            self.processed_folder,
                            file_name
                        )

                    shutil.move(
                        file_path,
                        destination
                    )

                    processed_files.add(
                        file_name
                    )

                    self.image_processed.emit(
                        result,
                        processing_time
                    )

                    time.sleep(2)

                except Exception as error:

                    self.status_changed.emit(
                        f"ERROR: {str(error)}"
                    )

            time.sleep(1)

        self.status_changed.emit(
            "AUTO MONITORING STOPPED"
        )

    def stop(self):

        self.running = False