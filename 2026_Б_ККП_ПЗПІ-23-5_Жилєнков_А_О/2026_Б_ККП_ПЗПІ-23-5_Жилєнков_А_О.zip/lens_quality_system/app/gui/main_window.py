from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QLabel,
    QPushButton,
    QFileDialog,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QFrame,
    QMessageBox
)

from PySide6.QtCore import Qt

from app.processing.image_processor import ImageProcessor
from app.utils.image_converter import ImageConverter

from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Image,
    Table,
    TableStyle
)

from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from reportlab.platypus import Image as RLImage

import os
import cv2
import time
import shutil

from app.monitoring.folder_monitor import FolderMonitor

from PySide6.QtGui import QIcon
from PySide6.QtGui import QPixmap
from datetime import datetime


class MainWindow(QMainWindow):

    AUTO_DEFECT_THRESHOLD = 1

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Lens Quality Control System"
        )

        self.setGeometry(
            100,
            100,
            1800,
            1000
        )

        self.showMaximized()

        self.current_result = None
        
        self.monitor = FolderMonitor()

        self.monitor.image_processed.connect(
            self.update_from_monitor
        )

        self.monitor.status_changed.connect(
            self.update_monitor_status
        )

        self.current_image_path = None

        self.create_widgets()

        self.create_layouts()

        self.setWindowIcon(QIcon("app/gui/logo.png"))

    def create_widgets(self):

        self.load_button = QPushButton(
            "Load Image"
        )

        self.load_button.clicked.connect(
            self.load_image
        )

        self.monitoring_button = QPushButton(
            "Start Monitoring"
        )

        self.monitoring_button.clicked.connect(
            self.toggle_monitoring
        )

        self.report_button = QPushButton(
            "Generate PDF Report"
        )

        self.report_button.clicked.connect(
            self.generate_pdf_report
        )

        self.tabs = QTabWidget()

        self.original_label = self.create_image_label(
            "Original Image"
        )

        self.gray_label = self.create_image_label(
            "Enhanced Grayscale Detection"
        )

        self.negative_label = self.create_image_label(
            "Negative Detection"
        )

        self.result_label = self.create_image_label(
            "Main Detection"
        )

        self.rays_label = self.create_image_label(
            "Lens Boundary Detection"
        )

        self.tabs.addTab(
            self.original_label,
            "Original"
        )

        self.tabs.addTab(
            self.result_label,
            "Detection"
        )

        self.tabs.addTab(
            self.rays_label,
            "Boundary Detection"
        )

        self.tabs.addTab(
            self.gray_label,
            "Enhanced"
        )

        self.tabs.addTab(
            self.negative_label,
            "Negative"
        )

        self.status_title = QLabel(
            "SYSTEM STATUS"
        )

        self.status_title.setAlignment(
            Qt.AlignCenter
        )

        self.status_title.setStyleSheet(
            """
            font-size: 22px;
            font-weight: bold;
            """
        )

        self.status_label = QLabel(
            "No analysis performed"
        )

        self.status_label.setAlignment(
            Qt.AlignCenter
        )

        self.defect_count_label = QLabel(
            "Detected defects: 0"
        )

        self.processing_time_label = QLabel(
            "Processing time: 0 sec"
        )

        self.lens_status_label = QLabel(
            "Lens detected: NO"
        )

        self.analysis_info_label = QLabel(
            "Analysis modes: Original + Enhanced + Negative"
        )

        self.coverage_label = QLabel(
            "Detect: 100% of lens\nAnalyse: 85% of lens"
        )

        self.sidebar_logo = QLabel()
        self.sidebar_logo.setFrameShape(QLabel.NoFrame)
        self.sidebar_logo.setStyleSheet("background: transparent; border: none;")
        self.sidebar_logo.setAlignment(Qt.AlignCenter)

        self.sidebar_logo.setPixmap(
            QPixmap("app/gui/logo.png").scaled(
                200,
                200,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

        self.info_frame = QFrame()

        self.info_frame.setStyleSheet(
            """
            QFrame {
                border: 2px solid gray;
                border-radius: 10px;
                padding: 10px;
            }

            QLabel {
                font-size: 16px;
            }
            """
        )

    def create_layouts(self):

        buttons_layout = QHBoxLayout()

        buttons_layout.addWidget(
            self.load_button
        )

        buttons_layout.addWidget(
            self.monitoring_button
        )

        buttons_layout.addWidget(
            self.report_button
        )

        info_layout = QVBoxLayout()

        info_layout.addWidget(
            self.status_title
        )

        info_layout.addSpacing(20)

        info_layout.addWidget(
            self.status_label
        )

        info_layout.addSpacing(20)

        info_layout.addWidget(
            self.defect_count_label
        )

        info_layout.addWidget(
            self.processing_time_label
        )

        info_layout.addWidget(
            self.lens_status_label
        )

        info_layout.addWidget(
            self.analysis_info_label
        )

        info_layout.addWidget(
            self.coverage_label
        )

        info_layout.addStretch()

        self.info_frame.setLayout(
            info_layout
        )

        info_layout.insertWidget(0, self.sidebar_logo)

        center_layout = QHBoxLayout()

        center_layout.addWidget(
            self.tabs,
            4
        )

        center_layout.addWidget(
            self.info_frame,
            1
        )

        main_layout = QVBoxLayout()

        main_layout.addLayout(
            buttons_layout
        )

        main_layout.addLayout(
            center_layout
        )

        container = QWidget()

        container.setLayout(
            main_layout
        )

        self.setCentralWidget(
            container
        )

    def create_image_label(self, text):

        label = QLabel(text)

        label.setAlignment(
            Qt.AlignCenter
        )

        label.setStyleSheet(
            """
            border: 2px solid gray;
            font-size: 18px;
            background-color: black;
            color: white;
            """
        )

        return label

    def load_image(self):

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Image",
            "",
            "Images (*.png *.jpg *.jpeg *.bmp)"
        )

        if not file_path:
            return

        self.process_single_image(
            file_path
        )

    def process_single_image(
        self,
        file_path
    ):

        start_time = time.time()

        result = ImageProcessor.process_image(
            file_path
        )

        end_time = time.time()

        processing_time = round(
            end_time - start_time,
            3
        )

        self.current_result = result
        self.current_image_path = file_path

        self.set_image(
            self.original_label,
            result["original"]
        )

        self.set_image(
            self.result_label,
            result["result"]
        )

        self.set_image(
            self.rays_label,
            result["rays"]
        )

        self.set_image(
            self.gray_label,
            result["gray"]
        )

        self.set_image(
            self.negative_label,
            result["negative"]
        )

        self.update_statistics(
            result,
            processing_time
        )

        return result

    def run_automatic_monitoring(self):

        incoming_folder = "images/incoming"
        processed_folder = "images/processed"
        defects_folder = "images/defects"

        os.makedirs(processed_folder, exist_ok=True)
        os.makedirs(defects_folder, exist_ok=True)

        valid_extensions = (".png", ".jpg", ".jpeg", ".bmp")

        while self.monitor.running:

            files = [
                f for f in os.listdir(incoming_folder)
                if f.lower().endswith(valid_extensions)
            ]

            if not files:
                time.sleep(0.5)
                continue

            for file_name in files:

                file_path = os.path.join(incoming_folder, file_name)

                if not os.path.exists(file_path):
                    continue

                result = self.process_single_image(file_path)

                QApplication.processEvents()

                time.sleep(0.5)

                defect_count = result["defect_count"]

                destination_folder = (
                    defects_folder
                    if defect_count > self.AUTO_DEFECT_THRESHOLD
                    else processed_folder
                )

                destination = os.path.join(destination_folder, file_name)

                if os.path.exists(file_path):
                    shutil.move(file_path, destination)

    def toggle_monitoring(self):

            if not self.monitor.running:

                self.monitor.start()

                self.monitoring_button.setText(
                    "Stop Monitoring"
                )

            else:

                self.monitor.stop()

                self.monitoring_button.setText(
                    "Start Monitoring"
                )

    def update_monitor_status(self, text):

        self.status_label.setText(text)

    def update_from_monitor(
        self,
        result,
        processing_time
    ):

        self.current_result = result

        self.set_image(
            self.original_label,
            result["original"]
        )

        self.set_image(
            self.result_label,
            result["result"]
        )

        self.set_image(
            self.rays_label,
            result["rays"]
        )

        self.set_image(
            self.gray_label,
            result["gray"]
        )

        self.set_image(
            self.negative_label,
            result["negative"]
        )

        self.update_statistics(
            result,
            processing_time
        )    

    def generate_pdf_report(self):

        if self.current_result is None:

            QMessageBox.warning(
                self,
                "Report",
                "No image analyzed"
            )

            return

        reports_folder = "reports"

        os.makedirs(
            reports_folder,
            exist_ok=True
        )

        timestamp = datetime.now().strftime(
            "%Y%m%d_%H%M%S"
        )

        image_name = os.path.basename(
            self.current_image_path
        )

        pdf_path = os.path.join(
            reports_folder,
            f"report_{timestamp}.pdf"
        )

        original_temp = os.path.join(
            reports_folder,
            "temp_original.jpg"
        )

        result_temp = os.path.join(
            reports_folder,
            "temp_result.jpg"
        )

        gray_temp = os.path.join(
            reports_folder,
            "temp_gray.jpg"
        )

        negative_temp = os.path.join(
            reports_folder,
            "temp_negative.jpg"
        )

        cv2.imwrite(
            original_temp,
            self.current_result["original"]
        )

        cv2.imwrite(
            result_temp,
            self.current_result["result"]
        )

        cv2.imwrite(
            gray_temp,
            self.current_result["gray"]
        )

        cv2.imwrite(
            negative_temp,
            self.current_result["negative"]
        )

        document = SimpleDocTemplate(
            pdf_path,
            pagesize=A4,
            rightMargin=20,
            leftMargin=20,
            topMargin=20,
            bottomMargin=20
        )

        styles = getSampleStyleSheet()

        elements = []

        title = Paragraph(
            "Lens Quality Analysis Report",
            styles["Title"]
        )

        elements.append(title)

        elements.append(
            Spacer(1, 10)
        )

        current_time = datetime.now().strftime(
            "%d.%m.%Y %H:%M:%S"
        )

        defect_count = self.current_result[
            "defect_count"
        ]

        status = self.current_result[
            "status"
        ]

        info_data = [

            ["Image Name", image_name],

            ["Detection Date", current_time],

            ["Defects Detected", str(defect_count)],

            ["System Status", status],

            [
                "Lens Detection",
                self.lens_status_label.text()
            ],

            [
                "Analysis Modes",
                "Original + Enhanced + Negative"
            ]
        ]

        info_table = Table(
            info_data,
            colWidths=[180, 320]
        )

        info_table.setStyle(
            TableStyle([

                (
                    "BACKGROUND",
                    (0, 0),
                    (0, -1),
                    colors.lightgrey
                ),

                (
                    "GRID",
                    (0, 0),
                    (-1, -1),
                    1,
                    colors.black
                ),

                (
                    "FONTNAME",
                    (0, 0),
                    (-1, -1),
                    "Helvetica"
                ),

                (
                    "FONTSIZE",
                    (0, 0),
                    (-1, -1),
                    10
                ),

                (
                    "BOTTOMPADDING",
                    (0, 0),
                    (-1, -1),
                    5
                ),

                (
                    "TOPPADDING",
                    (0, 0),
                    (-1, -1),
                    5
                )
            ])
        )

        elements.append(
            info_table
        )

        elements.append(
            Spacer(1, 15)
        )

        original_image = Image(
            original_temp,
            width=255,
            height=255
        )

        result_image = Image(
            result_temp,
            width=255,
            height=255
        )

        gray_image = Image(
            gray_temp,
            width=255,
            height=255
        )

        negative_image = Image(
            negative_temp,
            width=255,
            height=255
        )

        first_row = Table([
            [
                Paragraph(
                    "Original Image",
                    styles["Heading3"]
                ),

                Paragraph(
                    "Main Detection",
                    styles["Heading3"]
                )
            ],

            [
                original_image,
                result_image
            ]
        ])

        first_row.setStyle(
            TableStyle([

                (
                    "ALIGN",
                    (0, 0),
                    (-1, -1),
                    "CENTER"
                ),

                (
                    "BOTTOMPADDING",
                    (0, 0),
                    (-1, -1),
                    8
                )
            ])
        )

        elements.append(
            first_row
        )

        elements.append(
            Spacer(1, 10)
        )

        second_row = Table([
            [
                Paragraph(
                    "Enhanced Detection",
                    styles["Heading3"]
                ),

                Paragraph(
                    "Negative Detection",
                    styles["Heading3"]
                )
            ],

            [
                gray_image,
                negative_image
            ]
        ])

        second_row.setStyle(
            TableStyle([

                (
                    "ALIGN",
                    (0, 0),
                    (-1, -1),
                    "CENTER"
                ),

                (
                    "BOTTOMPADDING",
                    (0, 0),
                    (-1, -1),
                    8
                )
            ])
        )

        elements.append(
            second_row
        )

        document.build(
            elements
        )

        temp_files = [

            original_temp,
            result_temp,
            gray_temp,
            negative_temp
        ]

        for file in temp_files:

            if os.path.exists(file):

                os.remove(file)

        QMessageBox.information(
            self,
            "PDF Report",
            f"Report saved:\n{pdf_path}"
        )

    def set_image(self, label, image):

        pixmap = ImageConverter.cv_to_pixmap(
            image
        )

        label.setPixmap(
            pixmap.scaled(
                1200,
                850,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )
        )

    def update_statistics(
        self,
        result,
        processing_time
    ):

        defect_count = result[
            "defect_count"
        ]

        self.status_label.setText(
            result["status"]
        )

        self.defect_count_label.setText(
            f"Detected defects: {defect_count}"
        )

        self.processing_time_label.setText(
            f"Processing time: {processing_time} sec"
        )

        if result["status"] in [
            "Lens not detected",
            "Ellipse fitting failed"
        ]:

            self.lens_status_label.setText(
                "Lens detected: NO"
            )

            self.lens_status_label.setStyleSheet(
                "color: red; font-weight: bold;"
            )

        else:

            self.lens_status_label.setText(
                "Lens detected: YES"
            )

            self.lens_status_label.setStyleSheet(
                "color: lime; font-weight: bold;"
            )

        if defect_count > 0:

            self.status_label.setStyleSheet(
                """
                color: red;
                font-size: 20px;
                font-weight: bold;
                """
            )

        else:

            self.status_label.setStyleSheet(
                """
                color: lime;
                font-size: 20px;
                font-weight: bold;
                """
            )