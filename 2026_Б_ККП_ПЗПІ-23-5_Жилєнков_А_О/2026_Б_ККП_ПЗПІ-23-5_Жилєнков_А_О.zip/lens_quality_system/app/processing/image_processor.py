import cv2
import numpy as np
import math


class ImageProcessor:

    RAY_COUNT = 360
    EDGE_THRESHOLD = 35
    OUTLIER_THRESHOLD = 0.12

    MIN_LINE_LENGTH = 0

    SCRATCH_CANNY_LOW = 20
    SCRATCH_CANNY_HIGH = 100

    SCRATCH_HOUGH_THRESHOLD = 2
    SCRATCH_MAX_LINE_GAP = 10

    NEGATIVE_CANNY_LOW = 15
    NEGATIVE_CANNY_HIGH = 90

    @staticmethod
    def load_image_unicode(image_path):

        data = np.fromfile(
            image_path,
            dtype=np.uint8
        )

        return cv2.imdecode(
            data,
            cv2.IMREAD_COLOR
        )

    @staticmethod
    def enhance_contrast(gray):

        clahe = cv2.createCLAHE(
            clipLimit=3.0,
            tileGridSize=(8, 8)
        )

        return clahe.apply(gray)

    @staticmethod
    def radial_lens_detection(gray):

        h, w = gray.shape

        cx = w // 2
        cy = h // 2

        max_radius = min(cx, cy)

        points = []
        rays = []

        for angle in np.linspace(
            0,
            2 * np.pi,
            ImageProcessor.RAY_COUNT
        ):

            prev = int(gray[cy, cx])

            best_gradient = 0
            best_point = None

            for r in range(20, max_radius):

                x = int(cx + r * math.cos(angle))
                y = int(cy + r * math.sin(angle))

                if x < 0 or x >= w or y < 0 or y >= h:
                    break

                value = int(gray[y, x])

                gradient = abs(value - prev)

                if gradient > best_gradient:
                    best_gradient = gradient
                    best_point = (x, y)

                prev = value

            if (
                best_point is not None and
                best_gradient > ImageProcessor.EDGE_THRESHOLD
            ):
                points.append(best_point)

                rays.append(
                    (
                        (cx, cy),
                        best_point
                    )
                )

        return points, rays

    @staticmethod
    def filter_boundary_points(points):

        if len(points) < 20:
            return points

        cx = int(np.mean([p[0] for p in points]))
        cy = int(np.mean([p[1] for p in points]))

        distances = []

        for x, y in points:

            d = math.sqrt(
                (x - cx) ** 2 +
                (y - cy) ** 2
            )

            distances.append(d)

        median = np.median(distances)

        filtered = []

        for p, d in zip(points, distances):

            if median == 0:
                continue

            deviation = abs(d - median) / median

            if deviation < ImageProcessor.OUTLIER_THRESHOLD:
                filtered.append(p)

        return filtered

    @staticmethod
    def fit_lens_ellipse(points):

        if len(points) < 5:
            return None

        contour = np.array(
            points,
            dtype=np.int32
        )

        return cv2.fitEllipse(contour)

    @staticmethod
    def create_ellipse_mask(shape, ellipse):

        mask = np.zeros(
            shape[:2],
            dtype=np.uint8
        )

        cv2.ellipse(
            mask,
            ellipse,
            255,
            -1
        )

        return mask

    @staticmethod
    def create_inner_safe_mask(
        shape,
        ellipse,
        shrink=0.85
    ):

        mask = np.zeros(
            shape[:2],
            dtype=np.uint8
        )

        (cx, cy), (ax, ay), angle = ellipse

        safe = (
            (cx, cy),
            (ax * shrink, ay * shrink),
            angle
        )

        cv2.ellipse(
            mask,
            safe,
            255,
            -1
        )

        return mask

    @staticmethod
    def create_scratch_safe_mask(
        shape,
        ellipse,
        shrink=0.72
    ):

        mask = np.zeros(
            shape[:2],
            dtype=np.uint8
        )

        (cx, cy), (ax, ay), angle = ellipse

        safe = (
            (cx, cy),
            (ax * shrink, ay * shrink),
            angle
        )

        cv2.ellipse(
            mask,
            safe,
            255,
            -1
        )

        return mask

    @staticmethod
    def normalize_background(image):

        blur = cv2.GaussianBlur(
            image,
            (51, 51),
            0
        )

        diff = cv2.absdiff(
            image,
            blur
        )

        return cv2.normalize(
            diff,
            None,
            0,
            255,
            cv2.NORM_MINMAX
        )

    @staticmethod
    def detect_scratches(surface):

        normalized = (
            ImageProcessor.normalize_background(
                surface
            )
        )

        blurred = cv2.GaussianBlur(
            normalized,
            (5, 5),
            0
        )

        edges = cv2.Canny(
            blurred,
            ImageProcessor.SCRATCH_CANNY_LOW,
            ImageProcessor.SCRATCH_CANNY_HIGH
        )

        kernel = np.ones(
            (2, 2),
            np.uint8
        )

        edges = cv2.morphologyEx(
            edges,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=1
        )

        return edges

    @staticmethod
    def detect_negative_scratches(surface):

        negative = cv2.bitwise_not(surface)

        normalized = (
            ImageProcessor.normalize_background(
                negative
            )
        )

        blurred = cv2.GaussianBlur(
            normalized,
            (5, 5),
            0
        )

        edges = cv2.Canny(
            blurred,
            ImageProcessor.NEGATIVE_CANNY_LOW,
            ImageProcessor.NEGATIVE_CANNY_HIGH
        )

        kernel = np.ones(
            (2, 2),
            np.uint8
        )

        edges = cv2.morphologyEx(
            edges,
            cv2.MORPH_CLOSE,
            kernel,
            iterations=1
        )

        return edges

    @staticmethod
    def draw_detected_lines(
        result_image,
        line_mask,
        min_length
    ):

        count = 0

        lines = cv2.HoughLinesP(
            line_mask,
            1,
            np.pi / 180,
            threshold=ImageProcessor.SCRATCH_HOUGH_THRESHOLD,
            minLineLength=min_length,
            maxLineGap=ImageProcessor.SCRATCH_MAX_LINE_GAP
        )

        if lines is None:
            return 0

        used_lines = []

        for line in lines:

            x1, y1, x2, y2 = line[0]

            length = math.sqrt(
                (x2 - x1) ** 2 +
                (y2 - y1) ** 2
            )

            if length < min_length:
                continue

            duplicate = False

            for ux1, uy1, ux2, uy2 in used_lines:

                dist = math.sqrt(
                    (x1 - ux1) ** 2 +
                    (y1 - uy1) ** 2
                )

                if dist < 15:
                    duplicate = True
                    break

            if duplicate:
                continue

            used_lines.append(
                (x1, y1, x2, y2)
            )

            cv2.line(
                result_image,
                (x1, y1),
                (x2, y2),
                (0, 0, 255),
                2
            )

            count += 1

        return count

    @staticmethod
    def process_image(image_path):

        image = ImageProcessor.load_image_unicode(
            image_path
        )

        if image is None:
            raise ValueError(
                "Failed to load image"
            )

        result = image.copy()

        rays_result = image.copy()

        h, w = image.shape[:2]

        gray = cv2.cvtColor(
            image,
            cv2.COLOR_BGR2GRAY
        )

        enhanced = (
            ImageProcessor.enhance_contrast(
                gray
            )
        )

        points, rays = (
            ImageProcessor.radial_lens_detection(
                enhanced
            )
        )
        
        for start, end in rays:

            cv2.line(
                rays_result,
                start,
                end,
                (0, 255, 255),
                1
            )

            cv2.circle(
                rays_result,
                end,
                2,
                (0, 0, 255),
                -1
            )

        cv2.circle(
            rays_result,
            (w // 2, h // 2),
            6,
            (255, 0, 255),
            -1
        )

        points = (
            ImageProcessor.filter_boundary_points(
                points
            )
        )

        if len(points) < 20:

            return {
                "original": image,
                "gray": cv2.cvtColor(
                    enhanced,
                    cv2.COLOR_GRAY2BGR
                ),
                "negative": cv2.cvtColor(
                    cv2.bitwise_not(enhanced),
                    cv2.COLOR_GRAY2BGR
                ),
                "result": result,
                "rays": rays_result,
                "defect_count": 0,
                "status": "Lens not detected"
            }

        ellipse = (
            ImageProcessor.fit_lens_ellipse(
                points
            )
        )

        if ellipse is None:

            return {
                "original": image,
                "gray": cv2.cvtColor(
                    enhanced,
                    cv2.COLOR_GRAY2BGR
                ),
                "negative": cv2.cvtColor(
                    cv2.bitwise_not(enhanced),
                    cv2.COLOR_GRAY2BGR
                ),
                "result": result,
                "rays": rays_result,
                "defect_count": 0,
                "status": "Ellipse fitting failed"
            }

        cv2.ellipse(
            result,
            ellipse,
            (0, 255, 0),
            3
        )

        cv2.ellipse(
            rays_result,
            ellipse,
            (0, 255, 0),
            3
        )

        gray_result = cv2.cvtColor(
            enhanced,
            cv2.COLOR_GRAY2BGR
        )

        negative_image = cv2.bitwise_not(
            enhanced
        )

        negative_result = cv2.cvtColor(
            negative_image,
            cv2.COLOR_GRAY2BGR
        )

        cv2.ellipse(
            gray_result,
            ellipse,
            (0, 255, 0),
            3
        )

        cv2.ellipse(
            negative_result,
            ellipse,
            (0, 255, 0),
            3
        )

        (cx, cy), (ax, ay), angle = ellipse

        safe_ellipse = (
            (cx, cy),
            (ax * 0.85, ay * 0.85),
            angle
        )

        cv2.ellipse(
            result,
            safe_ellipse,
            (255, 0, 0),
            2
        )

        cv2.ellipse(
            rays_result,
            safe_ellipse,
            (255, 0, 0),
            2
        )

        cv2.ellipse(
            gray_result,
            safe_ellipse,
            (255, 0, 0),
            2
        )

        cv2.ellipse(
            negative_result,
            safe_ellipse,
            (255, 0, 0),
            2
        )

        lens_mask = (
            ImageProcessor.create_ellipse_mask(
                image.shape,
                ellipse
            )
        )

        inner_mask = (
            ImageProcessor.create_inner_safe_mask(
                image.shape,
                ellipse,
                0.85
            )
        )

        scratch_zone = (
            ImageProcessor.create_scratch_safe_mask(
                image.shape,
                ellipse,
                0.72
            )
        )

        valid_mask = cv2.bitwise_and(
            lens_mask,
            inner_mask
        )

        surface = cv2.bitwise_and(
            enhanced,
            enhanced,
            mask=valid_mask
        )

        scratch_mask = (
            ImageProcessor.detect_scratches(
                surface
            )
        )

        negative_mask = (
            ImageProcessor.detect_negative_scratches(
                surface
            )
        )

        scratch_mask = cv2.bitwise_and(
            scratch_mask,
            scratch_mask,
            mask=scratch_zone
        )

        negative_mask = cv2.bitwise_and(
            negative_mask,
            negative_mask,
            mask=scratch_zone
        )

        count = 0

        count += ImageProcessor.draw_detected_lines(
            result,
            scratch_mask,
            ImageProcessor.MIN_LINE_LENGTH
        )

        ImageProcessor.draw_detected_lines(
            gray_result,
            scratch_mask,
            ImageProcessor.MIN_LINE_LENGTH
        )

        ImageProcessor.draw_detected_lines(
            negative_result,
            negative_mask,
            ImageProcessor.MIN_LINE_LENGTH
        )

        status = (
            f"DEFECTS: {count}"
            if count > 0
            else "OK"
        )

        return {
            "original": image,
            "gray": gray_result,
            "negative": negative_result,
            "result": result,
            "rays": rays_result,
            "defect_count": count,
            "status": status
        }