import cv2

from PySide6.QtGui import QImage, QPixmap


class ImageConverter:

    @staticmethod
    def cv_to_pixmap(cv_image):

        if len(cv_image.shape) == 2:

            height, width = cv_image.shape

            bytes_per_line = width

            q_image = QImage(
                cv_image.data,
                width,
                height,
                bytes_per_line,
                QImage.Format_Grayscale8
            )

        else:

            rgb_image = cv2.cvtColor(
                cv_image,
                cv2.COLOR_BGR2RGB
            )

            height, width, channel = rgb_image.shape

            bytes_per_line = channel * width

            q_image = QImage(
                rgb_image.data,
                width,
                height,
                bytes_per_line,
                QImage.Format_RGB888
            )

        return QPixmap.fromImage(q_image)